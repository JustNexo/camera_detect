from collections import defaultdict
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Request, Form
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from app.camera_scope import DEFAULT_SITE_LABEL, normalize_site_for_display, parse_scope_key
from app.core.database import get_db
from app.core.security import get_current_user
from app.core.urls import app_url
from app.models import User, Violation, SystemSettings
from app.state import camera_status
from app.templating import templates

router = APIRouter(tags=["pages"])


def normalize_to_utc(dt: datetime) -> datetime:
    # SQLite часто возвращает naive datetime, поэтому явно приводим к UTC.
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _site_query_param_for_stream(parsed_site: str) -> str:
    if parsed_site == DEFAULT_SITE_LABEL:
        return ""
    return parsed_site


def build_site_camera_tree():
    """Группировка камер по объекту + флаги онлайн (heartbeat < 15 с)."""
    now = datetime.now(timezone.utc)
    by_site: dict[str, list[dict]] = defaultdict(list)

    for scope_key_str, seen in camera_status.items():
        site_part, cam_part = parse_scope_key(scope_key_str)
        site_d = normalize_site_for_display(site_part)
        seen_utc = normalize_to_utc(seen)
        delta = (now - seen_utc).total_seconds()
        by_site[site_d].append(
            {
                "scope_key": scope_key_str,
                "camera_name": cam_part,
                "site_display": site_d,
                "stream_site": _site_query_param_for_stream(site_d),
                "last_seen": seen.strftime("%Y-%m-%d %H:%M:%S"),
                "is_online": delta < 15,
            }
        )

    sites_out = []
    for site_name in sorted(by_site.keys()):
        cams = sorted(by_site[site_name], key=lambda x: x["camera_name"].lower())
        online_c = sum(1 for c in cams if c["is_online"])
        n = len(cams)
        sites_out.append(
            {
                "name": site_name,
                "cameras": cams,
                "online_count": online_c,
                "total": n,
                "all_online": n > 0 and online_c == n,
                "all_offline": n > 0 and online_c == 0,
            }
        )
    return sites_out


@router.get("/")
def root_redirect(request: Request):
    if request.session.get("user_id"):
        return RedirectResponse(url=app_url("/dashboard"), status_code=303)
    return RedirectResponse(url=app_url("/login"), status_code=303)


@router.get("/dashboard")
def dashboard(
    request: Request,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    violations = db.query(Violation).order_by(Violation.timestamp.desc()).limit(200).all()

    # Расчет метрик (KPI)
    now = datetime.now(timezone.utc)
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    today_violations_count = sum(
        1 for v in violations if normalize_to_utc(v.timestamp) >= today_start
    )

    active_cameras_count = sum(
        1
        for seen in camera_status.values()
        if (now - normalize_to_utc(seen)).total_seconds() < 15
    )
    attention_cameras_count = sum(
        1
        for seen in camera_status.values()
        if (now - normalize_to_utc(seen)).total_seconds() >= 15
    )

    return templates.TemplateResponse(
        request,
        "dashboard.html",
        {
            "user": current_user,
            "violations": violations,
            "today_violations_count": today_violations_count,
            "active_cameras_count": active_cameras_count,
            "attention_cameras_count": attention_cameras_count,
        },
    )


@router.get("/cameras")
def cameras_page(
    request: Request,
    current_user: User = Depends(get_current_user),
):
    sites = build_site_camera_tree()
    default_stream_site = ""
    default_camera = ""
    if sites and sites[0]["cameras"]:
        c0 = sites[0]["cameras"][0]
        default_stream_site = c0["stream_site"]
        default_camera = c0["camera_name"]

    return templates.TemplateResponse(
        request,
        "cameras.html",
        {
            "user": current_user,
            "sites": sites,
            "default_stream_site": default_stream_site,
            "default_camera": default_camera,
        },
    )


@router.get("/status")
def status_page(
    request: Request,
    current_user: User = Depends(get_current_user),
):
    sites = build_site_camera_tree()
    return templates.TemplateResponse(
        request,
        "status.html",
        {"user": current_user, "sites": sites},
    )


@router.get("/settings")
def settings_page(
    request: Request,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    settings = db.query(SystemSettings).first()
    if not settings:
        settings = SystemSettings(email_enabled=True, target_email="admin@qrpass.local")
        db.add(settings)
        db.commit()
        db.refresh(settings)

    return templates.TemplateResponse(
        request,
        "settings.html",
        {"user": current_user, "settings": settings, "success_msg": request.query_params.get("success")},
    )


@router.post("/settings")
def save_settings(
    request: Request,
    email_enabled: str = Form(default="off"),
    target_email: str = Form(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    settings = db.query(SystemSettings).first()
    if not settings:
        settings = SystemSettings()
        db.add(settings)

    settings.email_enabled = email_enabled == "on"
    settings.target_email = target_email
    db.commit()

    return RedirectResponse(url=app_url("/settings?success=1"), status_code=303)
