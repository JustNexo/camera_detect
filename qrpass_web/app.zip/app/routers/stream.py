import asyncio

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse

from app.camera_scope import scope_key
from app.core.security import get_current_user
from app.state import latest_frames

router = APIRouter(tags=["stream"])
STREAM_OUTPUT_FPS = 2.0
STREAM_OUTPUT_INTERVAL = 1.0 / STREAM_OUTPUT_FPS


def _resolve_frame_key(raw: str) -> str | None:
    """Найти ключ в latest_frames: полный JSON-ключ или legacy (только имя камеры)."""
    if raw in latest_frames:
        return raw
    legacy = scope_key(None, raw)
    if legacy in latest_frames:
        return legacy
    return None


async def stream_generator(frame_key: str):
    last_sent_frame: bytes | None = None
    while True:
        k = _resolve_frame_key(frame_key)
        frame = latest_frames.get(k) if k else None
        # Не пересылаем один и тот же JPEG многократно:
        # это резко уменьшает трафик, когда картинка на камере не меняется.
        if frame and frame != last_sent_frame:
            yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + frame + b"\r\n"
            last_sent_frame = frame
        await asyncio.sleep(STREAM_OUTPUT_INTERVAL)


@router.get("/stream/live")
async def camera_stream_live(
    site: str = Query("", description="Объект / площадка"),
    camera: str = Query(..., description="Имя камеры"),
    _: object = Depends(get_current_user),
):
    key = scope_key(site, camera)
    if _resolve_frame_key(key) is None:
        raise HTTPException(status_code=404, detail="Поток камеры пока недоступен")
    return StreamingResponse(
        stream_generator(key),
        media_type="multipart/x-mixed-replace; boundary=frame",
    )


@router.get("/stream/{camera_name:path}")
async def camera_stream_legacy(camera_name: str, _: object = Depends(get_current_user)):
    """Совместимость: старый URL с одним сегментом = только имя камеры (без объекта)."""
    if _resolve_frame_key(camera_name) is None:
        raise HTTPException(status_code=404, detail="Поток камеры пока недоступен")
    return StreamingResponse(
        stream_generator(scope_key("", camera_name)),
        media_type="multipart/x-mixed-replace; boundary=frame",
    )
