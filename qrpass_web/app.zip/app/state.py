from datetime import datetime

# Статусы камер в памяти: имя -> время последнего heartbeat/кадра.
camera_status: dict[str, datetime] = {}

# Последний JPEG-кадр для каждой камеры: имя -> bytes.
latest_frames: dict[str, bytes] = {}
